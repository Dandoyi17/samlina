<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Christmas Wish</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    include 'config.php';

    if (isset($_GET['id'])) {
        $unique_id = $_GET['id'];

        $stmt = $conn->prepare("SELECT sender, recipient, message FROM christmas WHERE unique_id = ?");
        $stmt->bind_param("s", $unique_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $sender = $row['sender'];
            $recipient = $row['recipient'];
            $message = $row['message'];

            // Random design
            $designs = ['design1', 'design2', 'design3'];
            $random_design = $designs[array_rand($designs)];

            // 20 different templates
            $templates = [
                "<div class='wish-container $random_design'><div class='decorations'>🎄 🌟 ❄️</div><h1>🎄 Merry Christmas, {recipient}! 🎄</h1><p>Dear {recipient}, {sender} has crafted a special Christmas wish just for you. Unwrap it below!</p><div class='flowers'>🌹🌸🌺</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎅 🦌 ⛄</div><h2>Ho Ho Ho! {recipient}</h2><p>{sender} sent you this festive message from Santa's workshop:</p><div class='flowers'>❄️❄️❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>✨ 🔔 🎁</div><h1>✨ Season's Greetings, {recipient}! ✨</h1><p>A magical Christmas wish from {sender} awaits you:</p><div class='flowers'>🌟🌟🌟</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎅 ❄️ 🌟</div><h2>Dear {recipient},</h2><p>{sender} has prepared this heartfelt Christmas message for you:</p><div class='flowers'>🌹🔔🌸</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎅 🦌 🎄</div><h1>🎅 {recipient}, Santa Called! 🎅</h1><p>{sender} delivered this special Christmas wish:</p><div class='flowers'>🌺❄️🌹</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🔔 🎁 ✨</div><h2>Jingle Bells for {recipient}!</h2><p>{sender}'s Christmas cheer:</p><div class='flowers'>🌟🔔🌟</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🌟 ❄️ 🎄</div><h1>🌟 Merry & Bright, {recipient}! 🌟</h1><p>A sparkling wish from {sender}:</p><div class='flowers'>❄️🌹❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎅 ⛄ 🦌</div><h2>{recipient}, You're on Santa's Nice List!</h2><p>{sender} sent this special message:</p><div class='flowers'>🌸🌺🌹</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>⛄ ❄️ 🔔</div><h1>❄️ Frosty Says Hi, {recipient}! ❄️</h1><p>{sender}'s winter wonderland wish:</p><div class='flowers'>❄️❄️❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎄 🌟 🎁</div><h2>Dear {recipient},</h2><p>May your Christmas be filled with joy! Here's {sender}'s message:</p><div class='flowers'>🌹🔔🌸</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎁 🦌 ✨</div><h1>🎁 Gift of Love for {recipient} 🎁</h1><p>{sender} wrapped this special wish for you:</p><div class='flowers'>🌺🌟🌹</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🔔 ⛄ 🎅</div><h2>{recipient}, Christmas Magic Awaits!</h2><p>{sender}'s enchanted message:</p><div class='flowers'>❄️🌸❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>⭐ 🎄 ❄️</div><h1>⭐ Starlight Wishes, {recipient}! ⭐</h1><p>From {sender} with love:</p><div class='flowers'>🌟🌹🌟</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎅 🦌 🎁</div><h2>Ho Ho Ho, {recipient}!</h2><p>Santa {sender} brings you this wish:</p><div class='flowers'>🔔🌺🔔</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎄 ⛄ 🌟</div><h1>🎄 Tannenbaum Time, {recipient}! 🎄</h1><p>{sender}'s festive greeting:</p><div class='flowers'>🌹❄️🌸</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>❄️ 🔔 🎅</div><h2>Dear {recipient},</h2><p>Wishing you a white Christmas! {sender} says:</p><div class='flowers'>❄️❄️❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🔔 🌟 🎄</div><h1>🔔 Bells Are Ringing for {recipient}! 🔔</h1><p>{sender}'s joyful message:</p><div class='flowers'>🌟🔔🌟</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎁 ✨ ⛄</div><h2>{recipient}, You're Special!</h2><p>{sender}'s Christmas love:</p><div class='flowers'>🌸🌺🌹</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>❄️ 🎅 🦌</div><h1>❄️ Snowy Wishes, {recipient}! ❄️</h1><p>From {sender} in the North Pole:</p><div class='flowers'>❄️🌹❄️</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>",
                "<div class='wish-container $random_design'><div class='decorations'>🎄 🔔 🌟</div><h2>Merry Christmas, {recipient}!</h2><p>{sender} crafted this special wish:</p><div class='flowers'>🌟🌸🌟</div><div class='message'>{message}</div><div id='animations'></div><a href='{share_link}' class='share-btn'>Share on WhatsApp</a><button class='download-btn' onclick='downloadWish()'>Download as Image</button><a href='index.php' class='create-another'>Create Another Wish</a></div>"
            ];

            $random_template = $templates[array_rand($templates)];

            $share_link = "https://wa.me/?text=" . urlencode("Hello $recipient, $sender has sent you a special Christmas wish. Click here: " . $_SERVER['HTTP_HOST'] . "/christmas/view.php?id=$unique_id");

            $output = str_replace(['{sender}', '{recipient}', '{message}', '{share_link}'], [$sender, $recipient, $message, $share_link], $random_template);

            echo $output;
        } else {
            echo "<p>Wish not found.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Invalid link.</p>";
    }

    $conn->close();
    ?>
    <script src="html2canvas.min.js"></script>
    <script src="script.js"></script>
</body>
</html>