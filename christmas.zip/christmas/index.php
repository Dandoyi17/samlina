<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Christmas Wishes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="christmas-effects">
        <div class="floating-tree tree1">🎄</div>
        <div class="floating-tree tree2">🌲</div>
        <div class="floating-santa santa1">🎅</div>
        <div class="floating-santa santa2">🦌</div>
        <div class="falling-confetti"></div>
    </div>
    <div class="container">
        <h1>Send a Special Christmas Wish to Your Loved One</h1>
        <form action="generate.php" method="post">
            <label for="sender">Your Name (Sender):</label>
            <input type="text" id="sender" name="sender" required>

            <label for="email">Your Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="recipient">Recipient's Name:</label>
            <input type="text" id="recipient" name="recipient" required>

            <label for="message">Your Special Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>

            <button type="submit">Generate Christmas Wish</button>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>