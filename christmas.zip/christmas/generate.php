<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sender = $_POST['sender'];
    $email = $_POST['email'];
    $recipient = $_POST['recipient'];
    $message = $_POST['message'];

    // Generate unique ID
    $unique_id = uniqid('wish_', true);

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO christmas (sender, recipient, email, message, unique_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $sender, $recipient, $email, $message, $unique_id);

    if ($stmt->execute()) {
        // Redirect to view page
        header("Location: view.php?id=" . $unique_id);
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>