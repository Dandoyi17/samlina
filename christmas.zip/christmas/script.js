// Function to download the wish as an image
function downloadWish() {
    const element = document.querySelector('.wish-container');
    const buttons = document.querySelectorAll('.share-btn, .download-btn, .create-another');
    const messageEl = document.querySelector('.message');
    
    // Temporarily hide the buttons and remove rainbow animation from message
    buttons.forEach(btn => btn.style.display = 'none');
    const originalAnimation = messageEl.style.animation;
    messageEl.style.animation = 'messageGlow 3s ease-in-out infinite alternate, fadeIn 2s ease-in';
    
    html2canvas(element, {
        backgroundColor: null, // To include the gradient background
        scale: 2 // Higher resolution
    }).then(canvas => {
        const link = document.createElement('a');
        link.download = 'christmas-wish.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
        
        // Show the buttons again and restore animation
        buttons.forEach(btn => btn.style.display = 'inline-block');
        messageEl.style.animation = originalAnimation;
    }).catch(error => {
        console.error('Error creating canvas:', error);
        alert('Error creating image: ' + error.message);
        
        // Show the buttons again and restore animation in case of error
        buttons.forEach(btn => btn.style.display = 'inline-block');
        messageEl.style.animation = originalAnimation;
    });
}

// Function to create lights
function createLights() {
    const container = document.querySelector('.wish-container');
    if (!container) return;

    for (let i = 0; i < 20; i++) {
        const light = document.createElement('div');
        light.className = 'light';
        light.style.left = Math.random() * 100 + '%';
        light.style.top = Math.random() * 100 + '%';
        light.style.animationDelay = Math.random() * 2 + 's';
        container.appendChild(light);
    }
}

// Function to create confetti
function createConfetti(containerSelector = '#animations') {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * 100 + '%';
        confetti.style.animationDelay = Math.random() * 3 + 's';
        confetti.style.background = `hsl(${Math.random() * 360}, 100%, 50%)`;
        container.appendChild(confetti);
    }
}

// Run animations on page load
window.onload = function() {
    createLights();
    if (document.querySelector('.falling-confetti')) {
        createConfetti('.falling-confetti');
    } else {
        createConfetti('#animations');
    }
};