<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "christmas";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    // echo "Database created successfully or already exists.\n";
} else {
    // echo "Error creating database: " . $conn->error . "\n";
}

// Select database
$conn->select_db($dbname);

// Create table if not exists
$table_sql = "CREATE TABLE IF NOT EXISTS christmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender VARCHAR(255) NOT NULL,
    recipient VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    unique_id VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($table_sql) === TRUE) {
    // echo "Table created successfully or already exists.\n";
} else {
    // echo "Error creating table: " . $conn->error . "\n";
}

// Add email column if not exists
$alter_sql = "ALTER TABLE christmas ADD COLUMN IF NOT EXISTS email VARCHAR(255) AFTER recipient";
if ($conn->query($alter_sql) === TRUE) {
    // echo "Email column added or already exists.\n";
} else {
    // echo "Error adding email column: " . $conn->error . "\n";
}
?>